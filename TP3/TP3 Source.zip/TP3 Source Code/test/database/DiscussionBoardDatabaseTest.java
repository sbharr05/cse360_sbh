package database;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import entityClasses.Post;
import entityClasses.Reply;

public class DiscussionBoardDatabaseTest {

	private Database db;

	// Track anything we create so we can clean it up after each test.
	private final ArrayList<Post> createdPosts = new ArrayList<>();
	private final ArrayList<Reply> createdReplies = new ArrayList<>();

	@BeforeEach
	void setUp() throws SQLException {
		db = new Database();
		db.connectToDatabase();
	}

	@AfterEach
	void tearDown() {
		// Replies first, then posts.
		for (Reply reply : createdReplies) {
			db.deleteReply(reply);
		}

		for (Post post : createdPosts) {
			db.deletePostReplies(post);
			db.deletePost(post);
		}

		createdReplies.clear();
		createdPosts.clear();
	}

	@Test
	void createPostAndGetDiscussionPosts_persistsPost() {
		Post post = newUniquePost();
		db.createPost(post);
		createdPosts.add(post);

		Post saved = findPostById(post.getID());

		assertNotNull(saved);
		assertEquals(post.getID(), saved.getID());
		assertEquals(post.getUser(), saved.getUser());
		assertEquals(post.getHeader(), saved.getHeader());
		assertEquals(post.getBody(), saved.getBody());
		assertEquals(post.getSolved(), saved.getSolved());
		assertEquals(post.getEdited(), saved.getEdited());
	}

	@Test
	void updatePost_persistsEditedHeaderBodyAndEditState() {
		Post post = newUniquePost();
		db.createPost(post);
		createdPosts.add(post);

		boolean changed = post.editPost("Updated Header " + uniqueSuffix(), "Updated Body " + uniqueSuffix());
		assertTrue(changed);

		db.updatePost(post);

		Post updated = findPostById(post.getID());

		assertNotNull(updated);
		assertEquals(post.getHeader(), updated.getHeader());
		assertEquals(post.getBody(), updated.getBody());
		assertTrue(updated.getEdited());
		assertNotNull(updated.getEditedTime());
	}

	@Test
	void updatePostSolvedStatus_persistsSolvedFlag() {
		Post post = newUniquePost();
		db.createPost(post);
		createdPosts.add(post);

		post.markAsSolved(true);
		db.updatePostSolvedStatus(post);

		Post solved = findPostById(post.getID());
		assertNotNull(solved);
		assertTrue(solved.getSolved());

		post.markAsSolved(false);
		db.updatePostSolvedStatus(post);

		Post reopened = findPostById(post.getID());
		assertNotNull(reopened);
		assertFalse(reopened.getSolved());
	}

	@Test
	void deletePost_removesPostFromDiscussionPosts() {
		Post post = newUniquePost();
		db.createPost(post);

		assertNotNull(findPostById(post.getID()));

		db.deletePost(post);

		Post deleted = findPostById(post.getID());
		assertNull(deleted);
	}

	@Test
	void createReplyAndGetPostReplies_persistsReplyUnderCorrectPost() {
		Post post = newUniquePost();
		db.createPost(post);
		createdPosts.add(post);

		Reply reply = newUniqueReply(post.getID());
		db.createReply(reply);
		createdReplies.add(reply);

		Reply saved = findReplyById(post.getID(), reply.getID());

		assertNotNull(saved);
		assertEquals(reply.getID(), saved.getID());
		assertEquals(reply.getUser(), saved.getUser());
		assertEquals(reply.getBody(), saved.getBody());
		assertEquals(reply.getPostID(), saved.getPostID());
		assertEquals(reply.getEditedBool(), saved.getEditedBool());
	}

	@Test
	void updateReply_persistsEditedBodyAndEditState() {
		Post post = newUniquePost();
		db.createPost(post);
		createdPosts.add(post);

		Reply reply = newUniqueReply(post.getID());
		db.createReply(reply);
		createdReplies.add(reply);

		boolean changed = reply.editReply("Updated reply body " + uniqueSuffix());
		assertTrue(changed);

		db.updateReply(reply);

		Reply updated = findReplyById(post.getID(), reply.getID());

		assertNotNull(updated);
		assertEquals(reply.getBody(), updated.getBody());
		assertTrue(updated.getEditedBool());
		assertNotNull(updated.getEditedTime());
	}

	@Test
	void deleteReply_removesReplyFromReplyMap() {
		Post post = newUniquePost();
		db.createPost(post);
		createdPosts.add(post);

		Reply reply = newUniqueReply(post.getID());
		db.createReply(reply);

		assertNotNull(findReplyById(post.getID(), reply.getID()));

		db.deleteReply(reply);

		Reply deleted = findReplyById(post.getID(), reply.getID());
		assertNull(deleted);
	}

	@Test
	void deletePostReplies_removesAllRepliesForOnePostOnly() {
		Post postA = newUniquePost();
		Post postB = newUniquePost();

		db.createPost(postA);
		db.createPost(postB);

		createdPosts.add(postA);
		createdPosts.add(postB);

		Reply replyA1 = newUniqueReply(postA.getID());
		Reply replyA2 = newUniqueReply(postA.getID());
		Reply replyB1 = newUniqueReply(postB.getID());

		db.createReply(replyA1);
		db.createReply(replyA2);
		db.createReply(replyB1);

		createdReplies.add(replyA1);
		createdReplies.add(replyA2);
		createdReplies.add(replyB1);

		assertNotNull(findReplyById(postA.getID(), replyA1.getID()));
		assertNotNull(findReplyById(postA.getID(), replyA2.getID()));
		assertNotNull(findReplyById(postB.getID(), replyB1.getID()));

		db.deletePostReplies(postA);

		assertNull(findReplyById(postA.getID(), replyA1.getID()));
		assertNull(findReplyById(postA.getID(), replyA2.getID()));
		assertNotNull(findReplyById(postB.getID(), replyB1.getID()));
	}

	// ---------- Helpers ----------

	private Post newUniquePost() {
		String suffix = uniqueSuffix();
		return new Post("testUser_" + suffix, "Header " + suffix, "Body " + suffix);
	}

	private Reply newUniqueReply(String postId) {
		String suffix = uniqueSuffix();
		return new Reply("replyUser_" + suffix, "Reply body " + suffix, postId);
	}

	private String uniqueSuffix() {
		return UUID.randomUUID().toString().substring(0, 8);
	}

	private Post findPostById(String postId) {
		for (Post post : db.getDiscussionPosts()) {
			if (post.getID().equals(postId)) {
				return post;
			}
		}
		return null;
	}

	private Reply findReplyById(String postId, String replyId) {
		HashMap<String, ArrayList<Reply>> allReplies = db.getPostReplies();
		ArrayList<Reply> repliesForPost = allReplies.get(postId);

		if (repliesForPost == null) {
			return null;
		}

		for (Reply reply : repliesForPost) {
			if (reply.getID().equals(replyId)) {
				return reply;
			}
		}
		return null;
	}
}