package admin;


//Enum for user roles
public enum Role {
    ADMIN, NEWROLE1, NEWROLE2, NONE; 
	}
